(()=>{var e={};e.id=712,e.ids=[712],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},7184:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},8704:(e,t,i)=>{"use strict";i.r(t),i.d(t,{GlobalError:()=>r.a,__next_app__:()=>m,originalPathname:()=>p,pages:()=>c,routeModule:()=>g,tree:()=>d}),i(5693),i(9239),i(5866);var a=i(3191),n=i(8716),s=i(7922),r=i.n(s),o=i(5231),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);i.d(t,l);let d=["",{children:["jobs",{children:["[id]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(i.bind(i,5693)),"C:\\Users\\etidi\\OneDrive\\Documents\\CMFAgency\\app\\jobs\\[id]\\page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(i.bind(i,9239)),"C:\\Users\\etidi\\OneDrive\\Documents\\CMFAgency\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(i.t.bind(i,5866,23)),"next/dist/client/components/not-found-error"]}],c=["C:\\Users\\etidi\\OneDrive\\Documents\\CMFAgency\\app\\jobs\\[id]\\page.tsx"],p="/jobs/[id]/page",m={require:i,loadChunk:()=>Promise.resolve()},g=new a.AppPageRouteModule({definition:{kind:n.x.APP_PAGE,page:"/jobs/[id]/page",pathname:"/jobs/[id]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},3349:(e,t,i)=>{Promise.resolve().then(i.bind(i,9379))},9379:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>x});var a=i(326),n=i(5047),s=i(6333),r=i(7546),o=i(7636),l=i(8998),d=i(1821),c=i(7358),p=i(5932),m=i(434),g=i(58);let u=[{id:1,title:"Senior Marketing Manager",company:"Changer Fusions Enterprise",location:"Remote / New York, NY",type:"Full-time",salary:"$80,000 - $120,000",posted:"2 days ago",description:"We're looking for an experienced marketing manager to lead our marketing initiatives.",fullDescription:`We are seeking a highly experienced and strategic Senior Marketing Manager to lead our marketing initiatives and drive business growth. The ideal candidate will have a proven track record in developing and executing comprehensive marketing strategies across multiple channels.

## Key Responsibilities:
- Develop and implement comprehensive marketing strategies aligned with business objectives
- Lead and manage the marketing team, fostering a collaborative and high-performance culture
- Oversee all marketing campaigns, from conception to execution and analysis
- Manage marketing budgets and ensure optimal ROI on all marketing spend
- Conduct market research and competitor analysis to identify opportunities
- Build and maintain strong relationships with key stakeholders and partners
- Analyze marketing metrics and provide regular reports to senior management
- Stay current with marketing trends and best practices

## Requirements:
- Bachelor's degree in Marketing, Business, or related field
- 7+ years of experience in marketing, with at least 3 years in a management role
- Strong leadership and team management skills
- Excellent communication and presentation skills
- Proven ability to develop and execute successful marketing campaigns
- Experience with digital marketing tools and platforms
- Strong analytical skills and data-driven decision making
- Ability to work in a fast-paced, dynamic environment`,requirements:["Bachelor's degree in Marketing, Business, or related field","7+ years of experience in marketing","Strong leadership and team management skills","Experience with digital marketing tools","Excellent communication skills"],benefits:["Competitive salary and benefits package","Flexible work arrangements","Professional development opportunities","Health and dental insurance","401(k) retirement plan"]},{id:2,title:"Event Coordinator",company:"Changer Fusions Enterprise",location:"Los Angeles, CA",type:"Full-time",salary:"$50,000 - $70,000",posted:"5 days ago",description:"Join our team to coordinate and manage exciting events for our clients.",fullDescription:`We are looking for a dynamic and organized Event Coordinator to join our team and help coordinate and manage exciting events for our clients. This role requires excellent organizational skills, attention to detail, and the ability to work under pressure.

## Key Responsibilities:
- Plan and coordinate events from conception to completion
- Manage event budgets and ensure cost-effectiveness
- Coordinate with vendors, venues, and suppliers
- Handle event registration and attendee management
- Create and manage event timelines and schedules
- Oversee event setup, execution, and breakdown
- Manage event marketing and promotion activities
- Collect and analyze event feedback and metrics
- Maintain relationships with clients and stakeholders

## Requirements:
- Bachelor's degree in Event Management, Hospitality, or related field
- 3+ years of experience in event planning and coordination
- Strong organizational and project management skills
- Excellent communication and interpersonal skills
- Ability to work flexible hours, including evenings and weekends
- Proficiency in event management software
- Detail-oriented with strong problem-solving abilities`,requirements:["Bachelor's degree in Event Management or related field","3+ years of event planning experience","Strong organizational skills","Ability to work flexible hours","Excellent communication skills"],benefits:["Competitive salary","Health insurance","Paid time off","Professional development support","Flexible schedule"]},{id:3,title:"Graphic Designer",company:"Changer Fusions Enterprise",location:"Remote",type:"Part-time",salary:"$40,000 - $60,000",posted:"1 week ago",description:"Creative graphic designer needed for branding and design projects.",fullDescription:`We are seeking a talented and creative Graphic Designer to join our team on a part-time basis. You will work on various branding and design projects, creating visually compelling materials that align with our clients' brand identities.

## Key Responsibilities:
- Create visual concepts and designs for various marketing materials
- Develop brand identities, logos, and visual guidelines
- Design print and digital materials including brochures, flyers, and social media graphics
- Collaborate with the marketing team to ensure brand consistency
- Present design concepts and incorporate feedback
- Manage multiple design projects simultaneously
- Stay current with design trends and best practices
- Work with clients to understand their design needs and preferences

## Requirements:
- Bachelor's degree in Graphic Design, Visual Arts, or related field
- 3+ years of professional graphic design experience
- Proficiency in Adobe Creative Suite (Photoshop, Illustrator, InDesign)
- Strong portfolio demonstrating creative and technical skills
- Excellent attention to detail
- Ability to work independently and meet deadlines
- Strong communication and collaboration skills`,requirements:["Bachelor's degree in Graphic Design or related field","3+ years of professional design experience","Proficiency in Adobe Creative Suite","Strong portfolio","Excellent attention to detail"],benefits:["Flexible work schedule","Remote work opportunity","Creative freedom","Competitive hourly rate","Portfolio building opportunities"]},{id:4,title:"Web Developer",company:"Changer Fusions Enterprise",location:"San Francisco, CA",type:"Full-time",salary:"$90,000 - $130,000",posted:"3 days ago",description:"Full-stack developer to build and maintain our platform and client websites.",fullDescription:`We are looking for an experienced Full-Stack Web Developer to build and maintain our platform and client websites. You will work on both front-end and back-end development, creating responsive and user-friendly web applications.

## Key Responsibilities:
- Develop and maintain web applications using modern frameworks and technologies
- Write clean, efficient, and well-documented code
- Collaborate with designers to implement responsive and visually appealing interfaces
- Build and maintain APIs and database systems
- Optimize applications for maximum speed and scalability
- Troubleshoot and debug applications
- Stay current with web development trends and best practices
- Participate in code reviews and team meetings

## Requirements:
- Bachelor's degree in Computer Science, Web Development, or related field
- 5+ years of experience in full-stack web development
- Proficiency in JavaScript, HTML, CSS, and modern frameworks (React, Next.js, Node.js)
- Experience with database systems (SQL, MongoDB)
- Strong problem-solving and debugging skills
- Excellent collaboration and communication skills
- Portfolio of web development projects`,requirements:["Bachelor's degree in Computer Science or related field","5+ years of full-stack development experience","Proficiency in JavaScript, React, Node.js","Experience with databases","Strong problem-solving skills"],benefits:["Competitive salary and equity","Health, dental, and vision insurance","401(k) with company match","Flexible work arrangements","Professional development budget","Stock options"]}];function x(){let e=(0,n.useParams)(),t=parseInt(e?.id),i=u.find(e=>e.id===t);return i||(0,n.notFound)(),a.jsx("div",{className:"pt-20 min-h-screen bg-gray-50",children:a.jsx("section",{className:"section-padding",children:(0,a.jsxs)("div",{className:"container-custom max-w-4xl",children:[a.jsx(g.E.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6},className:"mb-6",children:(0,a.jsxs)(m.default,{href:"/jobs",className:"inline-flex items-center space-x-2 text-primary-600 hover:text-primary-700 font-semibold transition-colors",children:[a.jsx(s.Z,{className:"w-5 h-5"}),a.jsx("span",{children:"Back to Jobs"})]})}),(0,a.jsxs)(g.E.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6},className:"bg-white rounded-xl shadow-lg p-8 mb-8",children:[(0,a.jsxs)("div",{className:"flex items-center space-x-3 mb-4",children:[a.jsx(r.Z,{className:"w-6 h-6 text-primary-600"}),a.jsx("h1",{className:"text-3xl md:text-4xl font-bold text-gray-900",children:i.title})]}),a.jsx("p",{className:"text-xl text-gray-600 mb-6",children:i.company}),(0,a.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4 mb-6",children:[(0,a.jsxs)("div",{className:"flex items-center text-gray-600",children:[a.jsx(o.Z,{className:"w-5 h-5 mr-2 text-primary-600"}),a.jsx("span",{children:i.location})]}),(0,a.jsxs)("div",{className:"flex items-center text-gray-600",children:[a.jsx(l.Z,{className:"w-5 h-5 mr-2 text-primary-600"}),a.jsx("span",{children:i.type})]}),(0,a.jsxs)("div",{className:"flex items-center text-gray-600",children:[a.jsx(d.Z,{className:"w-5 h-5 mr-2 text-primary-600"}),a.jsx("span",{children:i.salary})]}),(0,a.jsxs)("div",{className:"flex items-center text-gray-600",children:[a.jsx(c.Z,{className:"w-5 h-5 mr-2 text-primary-600"}),(0,a.jsxs)("span",{children:["Posted ",i.posted]})]})]}),a.jsx("div",{className:"flex gap-4",children:(0,a.jsxs)("a",{href:`mailto:info@cmfagency.co.ke?subject=Application for ${i.title}`,className:"btn-primary inline-flex items-center space-x-2",children:[a.jsx(p.Z,{className:"w-5 h-5"}),a.jsx("span",{children:"Apply Now"})]})})]}),(0,a.jsxs)(g.E.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6,delay:.1},className:"bg-white rounded-xl shadow-lg p-8 mb-8",children:[a.jsx("h2",{className:"text-2xl font-bold text-gray-900 mb-4",children:"Job Description"}),a.jsx("div",{className:"prose max-w-none text-gray-700 whitespace-pre-line",children:i.fullDescription})]}),(0,a.jsxs)(g.E.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6,delay:.2},className:"bg-white rounded-xl shadow-lg p-8 mb-8",children:[a.jsx("h2",{className:"text-2xl font-bold text-gray-900 mb-4",children:"Requirements"}),a.jsx("ul",{className:"space-y-3",children:i.requirements.map((e,t)=>(0,a.jsxs)("li",{className:"flex items-start space-x-3",children:[a.jsx("span",{className:"text-primary-600 mt-1",children:"•"}),a.jsx("span",{className:"text-gray-700",children:e})]},t))})]}),(0,a.jsxs)(g.E.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6,delay:.3},className:"bg-white rounded-xl shadow-lg p-8 mb-8",children:[a.jsx("h2",{className:"text-2xl font-bold text-gray-900 mb-4",children:"Benefits"}),a.jsx("ul",{className:"space-y-3",children:i.benefits.map((e,t)=>(0,a.jsxs)("li",{className:"flex items-start space-x-3",children:[a.jsx("span",{className:"text-primary-600 mt-1",children:"•"}),a.jsx("span",{className:"text-gray-700",children:e})]},t))})]}),(0,a.jsxs)(g.E.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.6,delay:.4},className:"bg-gradient-to-r from-primary-600 to-secondary-600 rounded-xl shadow-lg p-8 text-white text-center",children:[a.jsx("h2",{className:"text-3xl font-bold mb-4",children:"Ready to Apply?"}),a.jsx("p",{className:"text-xl text-white/90 mb-6",children:"Send us your resume and cover letter to get started."}),(0,a.jsxs)("a",{href:`mailto:info@cmfagency.co.ke?subject=Application for ${i.title}`,className:"inline-flex items-center space-x-2 bg-white text-primary-600 hover:bg-gray-100 font-semibold py-4 px-8 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl",children:[a.jsx(p.Z,{className:"w-5 h-5"}),a.jsx("span",{children:"Apply Now"})]})]})]})})})}},6333:(e,t,i)=>{"use strict";i.d(t,{Z:()=>a});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,i(2881).Z)("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]])},7546:(e,t,i)=>{"use strict";i.d(t,{Z:()=>a});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,i(2881).Z)("Briefcase",[["path",{d:"M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16",key:"jecpp"}],["rect",{width:"20",height:"14",x:"2",y:"6",rx:"2",key:"i6l2r4"}]])},7358:(e,t,i)=>{"use strict";i.d(t,{Z:()=>a});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,i(2881).Z)("Calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]])},8998:(e,t,i)=>{"use strict";i.d(t,{Z:()=>a});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,i(2881).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},1821:(e,t,i)=>{"use strict";i.d(t,{Z:()=>a});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,i(2881).Z)("DollarSign",[["line",{x1:"12",x2:"12",y1:"2",y2:"22",key:"7eqyqh"}],["path",{d:"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",key:"1b0p4s"}]])},5932:(e,t,i)=>{"use strict";i.d(t,{Z:()=>a});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,i(2881).Z)("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]])},7636:(e,t,i)=>{"use strict";i.d(t,{Z:()=>a});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,i(2881).Z)("MapPin",[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]])},5693:(e,t,i)=>{"use strict";i.r(t),i.d(t,{$$typeof:()=>r,__esModule:()=>s,default:()=>o});var a=i(8570);let n=(0,a.createProxy)(String.raw`C:\Users\etidi\OneDrive\Documents\CMFAgency\app\jobs\[id]\page.tsx`),{__esModule:s,$$typeof:r}=n;n.default;let o=(0,a.createProxy)(String.raw`C:\Users\etidi\OneDrive\Documents\CMFAgency\app\jobs\[id]\page.tsx#default`)}};var t=require("../../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),a=t.X(0,[948,319,756],()=>i(8704));module.exports=a})();