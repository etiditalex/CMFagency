# cPanel Deployment Instructions for Changer Fusions Enterprise

## 📦 What's Included in This Package

- **Production Build**: Optimized `.next` folder with all static and server-rendered pages
- **Source Files**: All application code (app/, components/, contexts/)
- **Configuration**: next.config.js, package.json, tsconfig.json
- **SEO Files**: sitemap.xml, robots.txt (auto-generated)
- **Dependencies**: package.json and package-lock.json for installation

## 🚀 Deployment Steps for cPanel

### Option 1: Node.js Application (Recommended if cPanel supports Node.js)

1. **Upload Files**
   - Upload all files to your cPanel public_html or a subdirectory
   - Ensure all files maintain their directory structure

2. **Install Dependencies**
   ```bash
   npm install --production
   ```

3. **Build (if not using pre-built)**
   ```bash
   npm run build
   ```

4. **Start Application**
   ```bash
   npm start
   ```

5. **Configure Node.js App in cPanel**
   - Go to cPanel → Node.js App
   - Create a new application
   - Set Application Root: `/home/username/public_html` (or your directory)
   - Set Application URL: Your domain
   - Set Application Startup File: `server.js` or configure to use `npm start`
   - Set Application Port: (auto-assigned)
   - Click "Create"

### Option 2: Static Export (If Node.js is not available)

If your cPanel doesn't support Node.js, you'll need to use a static export. However, note that some features may be limited.

1. **Update next.config.js** to include:
   ```javascript
   output: 'export',
   ```

2. **Rebuild**
   ```bash
   npm run build
   ```

3. **Upload the `out` folder** contents to your public_html directory

## ⚙️ Environment Variables

If you need to set environment variables in cPanel:

1. Go to cPanel → Node.js App → Your App → Environment Variables
2. Add any required variables (e.g., `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY`)

## 🔧 Configuration

### Domain Setup
- Update `app/layout.tsx` metadataBase URL to your actual domain
- Update `app/sitemap.ts` baseUrl to your actual domain
- Update `app/robots.ts` sitemap URL to your actual domain

### Google Maps API
- The Google Maps API key is currently in `app/contact/page.tsx`
- Consider moving it to an environment variable for security

## 📊 SEO Features Included

✅ **Meta Tags**: Comprehensive Open Graph and Twitter Card tags
✅ **Sitemap**: Auto-generated sitemap.xml at `/sitemap.xml`
✅ **Robots.txt**: Auto-generated robots.txt at `/robots.txt`
✅ **Structured Data**: Ready for Google Search Console
✅ **Performance**: Optimized images, compression, and caching
✅ **Mobile-Friendly**: Fully responsive design

## 🔍 Post-Deployment SEO Checklist

1. **Submit Sitemap to Google Search Console**
   - Go to https://search.google.com/search-console
   - Add your property
   - Submit sitemap: `https://yourdomain.com/sitemap.xml`

2. **Verify robots.txt**
   - Visit: `https://yourdomain.com/robots.txt`
   - Ensure it's accessible

3. **Test Meta Tags**
   - Use Facebook Debugger: https://developers.facebook.com/tools/debug/
   - Use Twitter Card Validator: https://cards-dev.twitter.com/validator

4. **Google Analytics** (Optional)
   - Add Google Analytics tracking code to `app/layout.tsx`

5. **Performance Testing**
   - Run Google PageSpeed Insights
   - Run Lighthouse audit

## 📝 Important Notes

- **Node.js Version**: Ensure your cPanel Node.js version is 18.x or higher
- **Port Configuration**: cPanel will assign a port for your Node.js app
- **SSL Certificate**: Ensure SSL is enabled for your domain
- **Domain Configuration**: Point your domain to the Node.js app URL

## 🆘 Troubleshooting

### Build Errors
- Ensure Node.js version is 18+ in cPanel
- Check that all dependencies are installed: `npm install`

### 404 Errors
- Verify that the `.next` folder was uploaded correctly
- Check that the Node.js app is running in cPanel

### SEO Issues
- Verify sitemap.xml is accessible
- Check robots.txt is accessible
- Ensure all meta tags are rendering correctly

## 📞 Support

For deployment issues, refer to:
- Next.js Deployment: https://nextjs.org/docs/deployment
- cPanel Node.js Documentation: Your hosting provider's docs

---

**Build Date**: $(Get-Date -Format "yyyy-MM-dd")
**Next.js Version**: 14.2.5
**Node.js Required**: 18.x or higher

