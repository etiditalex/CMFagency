import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PageLoader from "@/components/PageLoader";
import { CartProvider } from "@/contexts/CartContext";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: {
    default: "Changer Fusions Enterprise - Market to Thrive, Market to Exist",
    template: "%s | Changer Fusions Enterprise",
  },
  description: "Changer Fusions Enterprise (CMF) is a forward-thinking marketing strategic partner specializing in blending innovative marketing techniques, cutting-edge technologies, and transformative strategies. We harness the power of marketing as the catalyst for change and innovation.",
  keywords: ["Changer Fusions Enterprise", "CMF", "digital marketing", "website development", "branding", "market research", "events marketing", "content creation", "marketing strategy", "business growth", "Mombasa", "Kenya", "marketing agency", "event planning", "branding services"],
  authors: [{ name: "Changer Fusions Enterprise" }],
  creator: "Changer Fusions Enterprise",
  publisher: "Changer Fusions Enterprise",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://cmfagency.co.ke"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://cmfagency.co.ke",
    siteName: "Changer Fusions Enterprise",
    title: "Changer Fusions Enterprise - Market to Thrive, Market to Exist",
    description: "Changer Fusions Enterprise (CMF) is a forward-thinking marketing strategic partner specializing in blending innovative marketing techniques, cutting-edge technologies, and transformative strategies.",
    images: [
      {
        url: "https://res.cloudinary.com/dyfnobo9r/image/upload/v1765365917/cmfagency_logo_h1skcp.jpg",
        width: 1200,
        height: 630,
        alt: "Changer Fusions Enterprise Logo",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Changer Fusions Enterprise - Market to Thrive, Market to Exist",
    description: "Changer Fusions Enterprise - Forward-thinking marketing strategic partner specializing in innovative marketing techniques and transformative strategies.",
    images: ["https://res.cloudinary.com/dyfnobo9r/image/upload/v1765365917/cmfagency_logo_h1skcp.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    // Add Google Search Console verification code here when available
    // google: "your-verification-code",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <CartProvider>
          <PageLoader>
            <Navbar />
            <main className="min-h-screen">{children}</main>
            <Footer />
          </PageLoader>
        </CartProvider>
      </body>
    </html>
  );
}


